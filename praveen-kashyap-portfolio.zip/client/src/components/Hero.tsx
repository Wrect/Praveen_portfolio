import { ArrowRight, Download } from "lucide-react";
import { useEffect, useState } from "react";

export default function Hero() {
  const [displayStats, setDisplayStats] = useState({
    years: 0,
    companies: 0,
    projects: 0,
  });

  useEffect(() => {
    // Animate counter numbers on mount
    const intervals = [
      setInterval(() => {
        setDisplayStats((prev) => ({
          ...prev,
          years: Math.min(prev.years + 1, 4),
        }));
      }, 100),
      setInterval(() => {
        setDisplayStats((prev) => ({
          ...prev,
          companies: Math.min(prev.companies + 1, 3),
        }));
      }, 150),
      setInterval(() => {
        setDisplayStats((prev) => ({
          ...prev,
          projects: Math.min(prev.projects + 1, 50),
        }));
      }, 30),
    ];

    return () => intervals.forEach(clearInterval);
  }, []);

  return (
    <section
      id="hero"
      className="min-h-screen flex items-center justify-center pt-16 pb-20 md:pt-20 md:pb-32 relative overflow-hidden"
      style={{
        backgroundImage: "url('/manus-storage/hero-background_8c50bbdc.png')",
        backgroundSize: "cover",
        backgroundPosition: "center",
      }}
    >
      {/* Blueprint grid overlay */}
      <div className="absolute inset-0 blueprint-grid opacity-30 pointer-events-none" />

      <div className="container relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          {/* Left: Text & CTAs */}
          <div className="space-y-8">
            <div className="space-y-4">
              <h1 className="text-5xl md:text-6xl font-bold text-foreground leading-tight">
                Precision Design
                <span className="text-[#C17A45]">.</span>
              </h1>
              <p className="text-xl text-foreground/70 font-light leading-relaxed">
                Designing precision fixtures, gauges, and CAD systems that keep
                automotive production lines accurate, compliant, and efficient.
              </p>
            </div>

            {/* Animated Stats */}
            <div className="grid grid-cols-3 gap-6 py-8 border-y border-border">
              <div className="text-center md:text-left">
                <div className="text-3xl md:text-4xl font-bold text-[#C17A45]">
                  {displayStats.years}+
                </div>
                <p className="text-sm text-foreground/60 mt-1">Years Experience</p>
              </div>
              <div className="text-center md:text-left">
                <div className="text-3xl md:text-4xl font-bold text-[#C17A45]">
                  {displayStats.companies}
                </div>
                <p className="text-sm text-foreground/60 mt-1">Tier 1 Companies</p>
              </div>
              <div className="text-center md:text-left">
                <div className="text-3xl md:text-4xl font-bold text-[#C17A45]">
                  {displayStats.projects}+
                </div>
                <p className="text-sm text-foreground/60 mt-1">Designs Delivered</p>
              </div>
            </div>

            {/* CTAs */}
            <div className="flex flex-col sm:flex-row gap-4">
              <a
                href="#projects"
                className="inline-flex items-center justify-center gap-2 bg-[#C17A45] text-white font-semibold px-8 py-4 rounded-lg hover:bg-[#B5651D] transition-colors duration-200 shadow-md hover:shadow-lg"
              >
                View Projects
                <ArrowRight className="w-4 h-4" />
              </a>
              <a
                href="#contact"
                className="inline-flex items-center justify-center gap-2 border border-border text-foreground font-semibold px-8 py-4 rounded-lg hover:bg-card transition-colors duration-200"
              >
                <Download className="w-4 h-4" />
                Download Resume
              </a>
            </div>

            {/* Tech Stack */}
            <div className="space-y-3">
              <p className="text-sm font-semibold text-foreground/60 uppercase tracking-wide">
                Software Expertise
              </p>
              <div className="flex flex-wrap gap-2">
                {["CATIA V5", "SolidWorks", "AutoCAD", "GD&T", "PPAP"].map(
                  (tech) => (
                    <span
                      key={tech}
                      className="px-3 py-1 bg-card text-foreground/80 text-xs font-medium rounded-full border border-border"
                    >
                      {tech}
                    </span>
                  )
                )}
              </div>
            </div>
          </div>

          {/* Right: 3D CAD Viewer Placeholder */}
          <div className="hidden md:flex items-center justify-center">
            <div className="relative w-full h-96 bg-gradient-to-br from-card to-background rounded-lg border border-border shadow-lg overflow-hidden flex items-center justify-center">
              <div className="text-center space-y-4">
                <div className="w-24 h-24 mx-auto bg-[#C17A45]/10 rounded-lg flex items-center justify-center border border-[#C17A45]/20">
                  <svg
                    className="w-12 h-12 text-[#C17A45]"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={1.5}
                      d="M14 10l-2 1m0 0l-2-1m2 1v2.5M20 7l-2.75 1.5m0 0l-2.75-1.5m2.75 1.5v2.5M4 7l2.75 1.5m0 0L9.5 7m-2.75 1.5v2.5"
                    />
                  </svg>
                </div>
                <p className="text-foreground/60 text-sm font-medium">
                  3D CAD Viewer
                </p>
                <p className="text-foreground/40 text-xs">
                  Interactive welding fixture model
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
