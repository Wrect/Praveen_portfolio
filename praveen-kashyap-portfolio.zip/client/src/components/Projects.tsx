import { ArrowUpRight } from "lucide-react";

const projects = [
  {
    id: 1,
    title: "Welding Fixture Assembly",
    category: "Welding Fixture Design",
    industry: "Automotive Tier 1",
    software: ["CATIA V5", "SolidWorks"],
    difficulty: "Advanced",
    description:
      "Designed precision welding fixture for automotive body panel assembly with GD&T compliance and manufacturing coordination.",
    metrics: ["8 weeks", "3 iterations", "Zero defects"],
  },
  {
    id: 2,
    title: "Checking Gauge Development",
    category: "Gauge Design",
    industry: "Automotive Tier 1",
    software: ["AutoCAD", "CATIA V5"],
    difficulty: "Advanced",
    description:
      "Developed comprehensive checking gauge system for dimensional verification with full BOM and assembly documentation.",
    metrics: ["12 weeks", "5 revisions", "100% accuracy"],
  },
  {
    id: 3,
    title: "Pipeline Assembly Component",
    category: "Product Design",
    industry: "Automotive Tier 1",
    software: ["SolidWorks", "AutoCAD"],
    difficulty: "Intermediate",
    description:
      "Designed pipeline and hose assembly components to GD&T-compliant accuracy with parametric modeling.",
    metrics: ["6 weeks", "2 iterations", "Production ready"],
  },
  {
    id: 4,
    title: "New Tooling Development",
    category: "Tooling Design",
    industry: "Automotive Tier 1",
    software: ["CATIA V5", "AutoCAD"],
    difficulty: "Advanced",
    description:
      "Led end-to-end new tooling development from concept to production with cross-functional coordination.",
    metrics: ["16 weeks", "4 phases", "On schedule"],
  },
  {
    id: 5,
    title: "Reverse Engineering Project",
    category: "Legacy Redesign",
    industry: "Automotive Tier 1",
    software: ["SolidWorks", "AutoCAD"],
    difficulty: "Intermediate",
    description:
      "Reverse engineered legacy components and created modern CAD models with updated tolerances.",
    metrics: ["8 weeks", "3 components", "Modernized"],
  },
  {
    id: 6,
    title: "Production Drawing Suite",
    category: "Technical Documentation",
    industry: "Automotive Tier 1",
    software: ["AutoCAD", "CATIA V5"],
    difficulty: "Intermediate",
    description:
      "Created comprehensive 2D production drawings and BOMs for manufacturing and inspection workflows.",
    metrics: ["10 weeks", "45 drawings", "PPAP compliant"],
  },
];

export default function Projects() {
  return (
    <section id="projects" className="py-20 md:py-32 bg-background">
      <div className="container">
        <div className="mb-12">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
            Featured Projects
          </h2>
          <div className="w-12 h-1 bg-[#C17A45] rounded-full" />
          <p className="text-foreground/60 mt-4 max-w-2xl">
            A selection of precision engineering projects spanning welding fixtures,
            checking gauges, and automotive component design across Tier 1 manufacturers.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((project) => (
            <div
              key={project.id}
              className="group bg-card border border-border rounded-lg overflow-hidden hover:border-[#C17A45] hover:shadow-lg transition-all duration-300"
            >
              {/* Placeholder Image */}
              <div className="relative h-48 bg-gradient-to-br from-[#C17A45]/20 to-[#4A5A6A]/20 flex items-center justify-center overflow-hidden">
                <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 bg-gradient-to-t from-black/40 to-transparent" />
                <div className="text-center space-y-2 relative z-10">
                  <div className="w-16 h-16 mx-auto bg-[#C17A45]/20 rounded-lg flex items-center justify-center border border-[#C17A45]/30 group-hover:border-[#C17A45] transition-colors">
                    <svg
                      className="w-8 h-8 text-[#C17A45]"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={1.5}
                        d="M14 10l-2 1m0 0l-2-1m2 1v2.5M20 7l-2.75 1.5m0 0l-2.75-1.5m2.75 1.5v2.5M4 7l2.75 1.5m0 0L9.5 7m-2.75 1.5v2.5"
                      />
                    </svg>
                  </div>
                  <p className="text-xs text-foreground/60 font-medium">
                    CAD Model
                  </p>
                </div>
              </div>

              {/* Content */}
              <div className="p-6 space-y-4">
                {/* Category Badge */}
                <div className="flex items-center justify-between">
                  <span className="inline-block px-3 py-1 bg-[#C17A45]/10 text-[#C17A45] text-xs font-semibold rounded-full">
                    {project.category}
                  </span>
                  <span className="text-xs font-medium text-foreground/50">
                    {project.difficulty}
                  </span>
                </div>

                {/* Title & Description */}
                <div>
                  <h3 className="text-lg font-bold text-foreground mb-2">
                    {project.title}
                  </h3>
                  <p className="text-sm text-foreground/60 line-clamp-2">
                    {project.description}
                  </p>
                </div>

                {/* Software Tags */}
                <div className="flex flex-wrap gap-2">
                  {project.software.map((soft) => (
                    <span
                      key={soft}
                      className="px-2 py-1 bg-background border border-border rounded text-xs font-medium text-foreground/70"
                    >
                      {soft}
                    </span>
                  ))}
                </div>

                {/* Metrics */}
                <div className="pt-4 border-t border-border">
                  <div className="flex flex-wrap gap-3">
                    {project.metrics.map((metric) => (
                      <span
                        key={metric}
                        className="text-xs font-semibold text-[#C17A45]"
                      >
                        {metric}
                      </span>
                    ))}
                  </div>
                </div>

                {/* View Button */}
                <a
                  href={`/case-study/${project.id}`}
                  className="w-full mt-4 flex items-center justify-center gap-2 py-2 text-sm font-semibold text-[#C17A45] hover:text-[#B5651D] transition-colors group/btn"
                >
                  View Case Study
                  <ArrowUpRight className="w-4 h-4 group-hover/btn:translate-x-1 group-hover/btn:-translate-y-1 transition-transform" />
                </a>
              </div>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div className="mt-16 text-center">
          <p className="text-foreground/60 mb-6">
            Have a similar fixture or tolerance challenge?
          </p>
          <a
            href="#contact"
            className="inline-flex items-center gap-2 bg-[#C17A45] text-white font-semibold px-8 py-3 rounded-lg hover:bg-[#B5651D] transition-colors duration-200 shadow-md hover:shadow-lg"
          >
            Let's Talk
            <ArrowUpRight className="w-4 h-4" />
          </a>
        </div>
      </div>
    </section>
  );
}
