const softwareTools = [
  {
    name: "CATIA V5",
    level: "Advanced",
    skills: [
      "Part Design",
      "Assembly Design",
      "Drafting",
      "Generative Shape Design",
      "Generative Sheetmetal Design",
    ],
    proficiency: 95,
  },
  {
    name: "SolidWorks",
    level: "Advanced",
    skills: ["3D Modeling", "Simulation", "Assemblies", "Drafting"],
    proficiency: 90,
  },
  {
    name: "AutoCAD",
    level: "Proficient",
    skills: ["2D Drafting", "Technical Drawing", "Annotation"],
    proficiency: 80,
  },
  {
    name: "Microsoft Office",
    level: "Proficient",
    skills: ["Word", "Excel", "PowerPoint"],
    proficiency: 85,
  },
];

export default function Software() {
  return (
    <section id="software" className="py-20 md:py-32 bg-card/30">
      <div className="container">
        <div className="mb-12">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
            Software Expertise
          </h2>
          <div className="w-12 h-1 bg-[#C17A45] rounded-full" />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {softwareTools.map((tool) => (
            <div
              key={tool.name}
              className="bg-background border border-border rounded-lg p-8 hover:shadow-lg transition-all duration-200 hover:border-[#C17A45]/50"
            >
              {/* Header */}
              <div className="flex items-start justify-between mb-6">
                <div>
                  <h3 className="text-2xl font-bold text-foreground">
                    {tool.name}
                  </h3>
                  <p className="text-sm font-medium text-[#C17A45] mt-1">
                    {tool.level}
                  </p>
                </div>
              </div>

              {/* Proficiency Bar */}
              <div className="mb-6">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-semibold text-foreground/60 uppercase tracking-wide">
                    Proficiency
                  </span>
                  <span className="text-sm font-semibold text-[#C17A45]">
                    {tool.proficiency}%
                  </span>
                </div>
                <div className="w-full h-2 bg-border rounded-full overflow-hidden">
                  <div
                    className="h-full bg-[#C17A45] rounded-full transition-all duration-500"
                    style={{ width: `${tool.proficiency}%` }}
                  />
                </div>
              </div>

              {/* Skills */}
              <div className="space-y-3">
                <p className="text-xs font-semibold text-foreground/60 uppercase tracking-wide">
                  Key Skills
                </p>
                <div className="flex flex-wrap gap-2">
                  {tool.skills.map((skill) => (
                    <span
                      key={skill}
                      className="px-3 py-1 bg-card border border-border rounded-full text-xs font-medium text-foreground/70 hover:text-[#C17A45] transition-colors"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Workflow Strip */}
        <div className="mt-16 pt-12 border-t border-border">
          <p className="text-sm font-semibold text-foreground/60 uppercase tracking-wide mb-6">
            Design & Manufacturing Workflow
          </p>
          <div className="flex flex-wrap gap-4 md:gap-6">
            {[
              "Requirements",
              "Concept",
              "CAD Modeling",
              "Assembly",
              "Drafting",
              "Manufacturing",
              "Inspection",
            ].map((step, idx) => (
              <div key={step} className="flex items-center gap-4 md:gap-6">
                <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-[#C17A45]/10 border border-[#C17A45]/20">
                  <span className="text-xs font-bold text-[#C17A45]">{idx + 1}</span>
                </div>
                <span className="text-sm font-medium text-foreground hidden sm:inline">
                  {step}
                </span>
                {idx < 6 && (
                  <span className="text-[#C17A45]/50 text-lg hidden md:inline">→</span>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
